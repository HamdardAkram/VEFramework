//
//  VideoEditorLib.h
//  VideoEditorLib
//
//  Created by Muhammad Akram on 16/09/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for VideoEditorLib.
FOUNDATION_EXPORT double VideoEditorLibVersionNumber;

//! Project version string for VideoEditorLib.
FOUNDATION_EXPORT const unsigned char VideoEditorLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VideoEditorLib/PublicHeader.h>


